var toastLiveExample = document.querySelectorAll('.toast')

toastLiveExample.forEach((e)=>{
    if (e) {
        e.classList.add('show');
    }
})


